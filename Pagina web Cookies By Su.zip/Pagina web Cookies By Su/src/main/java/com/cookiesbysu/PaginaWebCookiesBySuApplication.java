package com.cookiesbysu;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PaginaWebCookiesBySuApplication {

	public static void main(String[] args) {
		SpringApplication.run(PaginaWebCookiesBySuApplication.class, args);
	}

}
