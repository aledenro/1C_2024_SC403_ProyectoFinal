package com.cookiesbysu.service;

import com.cookiesbysu.domain.Usuario;

public interface UsuarioService {

    public Usuario getUsuario(Usuario usuario);

    public void saveUsuario(Usuario usuario);

}
