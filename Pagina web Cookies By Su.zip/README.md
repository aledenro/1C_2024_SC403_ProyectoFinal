# 1C_2024_SC403_ProyectoFinal
Proyecto Final Desarrollo de Aplicaciones Web y Patrones
Grupo 2
Integrantes:
-Alejandro Denver Romero
-Valeria Solano Vargas
-Melissa Sanchez Castro
-Katherine Benavides Gutierrez

Link al repositorio https://github.com/aledenro/1C_2024_SC403_ProyectoFinal.git